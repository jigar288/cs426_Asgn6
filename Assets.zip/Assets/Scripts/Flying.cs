using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Flying : MonoBehaviour {
    [SerializeField] GameObject player;
    public float orbitDistance = 1.0f;
    public float orbitDegreesPerSec = 5.0f;
    public Vector3 relativeDistance = Vector3.zero;
    public bool once = true;
    // Start is called before the first frame update
    void Start()
    {
        transform.position = new Vector3(transform.position.x, player.transform.position.y+1f, transform.position.z);
        transform.Rotate(new Vector3(0, -90f, 0));
        if(player != null) 
            relativeDistance = transform.position - player.transform.position;
    }

    // Update is called once per frame
    void LateUpdate()
    {
        if(player != null) {
            // Keep us at the last known relative position
            transform.position = (player.transform.position + relativeDistance);
            transform.RotateAround(player.transform.position, Vector3.up, orbitDegreesPerSec * Time.deltaTime);
            // Reset relative position after rotate
            if (once) {
                transform.position *= orbitDistance;
                once = false;
            }
            relativeDistance = transform.position - player.transform.position;
        }
    }
}
