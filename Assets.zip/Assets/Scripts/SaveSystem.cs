using UnityEngine;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

public static class SaveSystem {
    private static string path = Application.persistentDataPath + "/player.data";
    public static void SavePlayer(PlayerController pc) {
        BinaryFormatter formatter = new BinaryFormatter();
        FileStream stream = new FileStream(path, FileMode.Create);

        SaveData data = new SaveData(pc);

        formatter.Serialize(stream, data);
        stream.Close();
    } // End of SavePlayer

    public static SaveData LoadPlayer() {
        SaveData data = null;

        if(!File.Exists(path))
            SavePlayer(null);

        if(File.Exists(path)) {
            BinaryFormatter formatter = new BinaryFormatter();
            FileStream stream = new FileStream(path, FileMode.Open);

            data = (SaveData)formatter.Deserialize(stream);
            stream.Close();
        } else {
            // data = new SaveData();
            Debug.LogError("Save file not found in " + path);
        }

        return data;
    } // End of LoadPlayer
}
