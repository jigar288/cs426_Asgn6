using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class SaveData {
    public const int numOfLevels = 2;
    public const int numOfInfo = 2;

    // levelInfo[..., 0] == Fish count
    // levelInfo[..., 1] == level completed (0: false, 1: true)
    public int[] fishInfo = new int[numOfLevels]; // Fish collected for each level
    public int levelInfo; // Level completed

    public SaveData(PlayerController pc) {
        if(pc != null) {
            levelInfo = pc.level_choice; // Increase level selection
            fishInfo[levelInfo-1] = Mathf.Min(Mathf.Max(fishInfo[levelInfo-1], pc.fishCount), 2);
        } else {
            levelInfo = 0;
            fishInfo = new int[numOfLevels];
        }
    } // End of SaveData

    public SaveData() {
        levelInfo = 0;
        fishInfo = new int[numOfLevels];
    } // End of SaveData
}
