using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EndPoleCollider : MonoBehaviour {
    [SerializeField] private AudioClip mAudio;
    private AudioSource mAudioSource;
    // Start is called before the first frame update
    void Start() {
        mAudioSource = GetComponent<AudioSource>();
    } // End of Start

    void OnTriggerEnter(Collider other) {
        if(other.gameObject.CompareTag("PlayerObj")) {
            mAudioSource.PlayOneShot(mAudio);
            other.gameObject.GetComponentInChildren<PlayerController>().winScreen.SetActive(true);
            other.gameObject.GetComponentInChildren<PlayerController>().enabled = false;
        }
    } // End of OnTriggerEnter
}
