using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using UnityEngine.UI; 
using System.Linq;

class Tile{


    public int X  {get; set; }
    public int Y  {get; set; }
    public int Cost  {get; set; }
    public int Distance  {get; set; }
    public int CostDistance  => Cost + Distance; 
    public Tile parent {get; set;}

    public void SetDistance(int targetX, int targetY){

        this.Distance = Math.Abs(targetX - X) + Math.Abs(targetY - Y);
    }


}

public class PlayerController : MonoBehaviour {
    [SerializeField] GameObject player, parent;
    [SerializeField] float playerSpeed = 0.3f;
    private Animator mAnimator;
    private bool animMovement, isMoving, dropPlayer = false;
    private Vector3 mMovement = Vector3.zero, mPlayerPos;

    public AudioSource aud, audCamQ, audCamE;
    private AudioSource mAudioSource;
    [SerializeField] private AudioClip mAudio_invalid_move;


    public Text helptext; 
    int helpnum = 1; 

    //direction of the bear going 1-4
    int direction = 1; 

    public GameObject pauseScreen, winScreen;

    //level
    public int[,] level;

    public int level_choice;
    public int fishCount = 0;
    
    //bear position
    public int bearx = 14;
    public int beary = 1;

    public int endx = 7;
    public int endy = 2;

    int pauseFlag = 0; 

    void Start() {
        mAnimator = parent.gameObject.GetComponentInChildren<Animator>();
        mAudioSource = GetComponent<AudioSource>();

        //endtext.enabled = false;
        helptext.enabled = false;
        isMoving = false;
        animMovement = false;

        level = LevelMapping.levels[level_choice-1];
        // level = levels[level_choice];
    } // End of Start


    (int, int) A_Star(){ 

        var bearStart = new Tile();
        bearStart.X = bearx;
        bearStart.Y = beary;

        var finish = new Tile();
        finish.X = endx;
        finish.Y = endy; 
        
        bearStart.SetDistance(endx, endy);

        var activeTiles = new List<Tile>();
        activeTiles.Add(bearStart);
        var visitedTiles = new List<Tile>();            

        while(activeTiles.Any()){
            
            var checkTile = activeTiles.OrderBy(x => x.CostDistance).First(); 

            if(checkTile.X == finish.X && checkTile.Y == finish.Y)
            {
                // Debug.Log("Done");

                var t = checkTile; 

                while(true){

                    if(t.parent.parent == null){
                        return (t.X, t.Y);
                    }
                    t = t.parent; 
                }
            }

            visitedTiles.Add(checkTile);
            activeTiles.Remove(checkTile);

            var walkTiles = GetWalkableTiles(checkTile, finish);

            foreach (var wt in walkTiles){
                if(visitedTiles.Any(x => x.X == wt.X && x.Y == wt.Y))
                    continue; 
                if(activeTiles.Any(x => x.X == wt.X && x.Y == wt.Y)){
                    var existingTile = activeTiles.First(x => x.X == wt.X && x.Y == wt.Y);

                    if(existingTile.CostDistance > checkTile.CostDistance){
                        activeTiles.Remove(existingTile);
                        activeTiles.Add(wt);
                    }
                }else{
                    activeTiles.Add(wt);
                }
            }
        }

        return (-1,-1); 
    }

    private List<Tile> GetWalkableTiles(Tile currentTile, Tile targetTile){

        

        var possibleTiles = new List<Tile>()
        { 
            new Tile {X = currentTile.X, Y = currentTile.Y - 1, parent = currentTile, Cost = currentTile.Cost + 1},
            new Tile {X = currentTile.X, Y = currentTile.Y + 1, parent = currentTile, Cost = currentTile.Cost + 1},
            new Tile {X = currentTile.X - 1, Y = currentTile.Y, parent = currentTile, Cost = currentTile.Cost + 1},
            new Tile {X = currentTile.X + 1, Y = currentTile.Y, parent = currentTile, Cost = currentTile.Cost + 1}
        };

        possibleTiles.ForEach(tile => tile.SetDistance(targetTile.X, targetTile.Y));

        var realizedTiles = new List<Tile>();

        foreach (Tile t in possibleTiles){

            //check if valid tile to jump to
            if(availTile(t, currentTile)){
                
                //add to list if so
                realizedTiles.Add(t);

            }
        }

        return realizedTiles;  
    }

    bool availTile(Tile t1, Tile t2){

        int tile1 = level[t1.X, t1.Y];
        int tile2 = level[t2.X, t2.Y]; 

        if(Math.Abs(tile1 - tile2) > 1)
            return false; 

        return true; 
    }
    

    // Update is called once per frame
    void Update() {

        // print(bearx + "   " + beary);
    
        if(Input.GetKeyDown(KeyCode.Q)){
            audCamQ.Play();
            transform.RotateAround(player.transform.position, Vector3.up, 90f);
        }
        else if(Input.GetKeyDown(KeyCode.E)){
            audCamE.Play();
            transform.RotateAround(player.transform.position, Vector3.up, -90f);
        }
        if(!isMoving) {
            if(Input.GetKeyDown(KeyCode.A) || Input.GetKeyDown(KeyCode.LeftArrow)) {
                player.transform.Rotate(Vector3.up*-90f); // Rotate player

                direction--; // Change direction of player for grid
                if(direction == 0)
                    direction = 4;
            
            } else if(Input.GetKeyDown(KeyCode.D) || Input.GetKeyDown(KeyCode.RightArrow)) {
                player.transform.Rotate(Vector3.up*90f); // Rotate player

                direction++; // Change direction of player for grid
                if(direction == 5)
                    direction = 1;
                
            } else if(Input.GetKeyDown(KeyCode.W) || Input.GetKeyDown(KeyCode.UpArrow)) {
                bool validMove = checkMovement();


                // Debug.Log(validMove);

                if(validMove) {
                    handleHeight();
                    aud.Play();
                } else {
                    mAnimator.Play("shaking_head");
                    mAudioSource.PlayOneShot(mAudio_invalid_move);
                }


                if(direction == 1 && validMove) {
                    // parent.transform.position += Vector3.forward;
                    // Debug.Log("Forward");
                    mMovement = Vector3.forward;
                    animMovement = true;
                    beary--;
                }
                if(direction == 2 && validMove) {
                    // parent.transform.position += Vector3.right;
                    // Debug.Log("Right");
                    mMovement = Vector3.right;
                    animMovement = true;
                    bearx++; 
                }
                if(direction == 3 && validMove) {
                    // parent.transform.position += Vector3.back;
                    // Debug.Log("Backward");
                    mMovement = Vector3.back;
                    animMovement = true;
                    beary++; 
                }
                if(direction == 4 && validMove) {
                    // parent.transform.position += Vector3.left;
                    // Debug.Log("Left");
                    mMovement = Vector3.left;
                    animMovement = true;
                    bearx--;  
                }
            } else if(Input.GetKeyDown(KeyCode.H)){
                helptext.enabled = true; 
                var coors = A_Star();

                int hintx = coors.Item1;
                int hinty = coors.Item2;

                if(helpnum == 1)
                    helptext.text = "Hint: " + coors.Item1 + ", " + coors.Item2;

                helpnum = 0;
                
                /*
                if(hintx == -1){
                    helptext.text = "No Possible Solution";
                }
                else if(hintx < bearx){
                    helptext.text = "Go Left";
                }
                else if(hintx > bearx){
                    helptext.text = "Go Right";
                }
                else if(hinty < bearx){
                    helptext.text = "Go Up";
                }
                else if(hinty < bearx){
                    helptext.text = "Go Down";
                }
                else{
                    helptext.text = "End?";
                }*/
                

                // Debug.Log(coors);
                // Debug.Log(bearx + " " + beary);
                Debug.Log("My Fish Count: " + fishCount);
            }
            else if(Input.GetKeyDown(KeyCode.P)){
                
                if(pauseFlag % 2 == 0){
                    pauseScreen.SetActive(true); 
                }
                else{
                    pauseScreen.SetActive(false);
                }

                pauseFlag++; 
            }
        }

        // Animation movement FSM
        if(animMovement && !isMoving) {
            isMoving = true;
            animMovement = false;
            mPlayerPos = parent.transform.position;
        }

        if(isMoving) {
            float step = playerSpeed * Time.deltaTime; // Uncomment for normal player speed
            parent.transform.position = Vector3.MoveTowards(parent.transform.position,
                                            mPlayerPos+mMovement, step);
            if(Vector3.Distance(parent.transform.position, mPlayerPos+mMovement) < 0.001f) {
                isMoving = false;
                if(dropPlayer) {
                    parent.transform.position += Vector3.down;
                    dropPlayer = false;
                }
            }
        }
        // End of animation movement FSM

        // Set animations
        mAnimator.SetBool("walking", isMoving);
    } // End of Update

    void handleHeight(){

        int delta = getDelta(); 

        if(delta == 1){
            parent.transform.position += Vector3.up; 
        }
        if(delta == -1){
            // parent.transform.position += Vector3.down;
            dropPlayer = true;
        }
    }

    bool checkMovement(){

        if(Math.Abs(getDelta()) > 1){
            return false;
        }

        return true;
    }

    int getDelta(){
        int delta = 0;
        
        if(direction == 1){
            delta = level[beary - 1, bearx] - level[beary, bearx];
        } 
        if(direction == 2){
            delta = level[beary, bearx + 1] - level[beary, bearx];
        }
  
        if(direction == 3){

            delta = level[beary + 1, bearx] - level[beary, bearx];
        }
        if(direction == 4){

            delta = level[beary, bearx - 1] - level[beary, bearx];
        }

        return delta; 
    }

    IEnumerator Animation(String mAnim, bool mBool) {
        mAnimator.SetBool(mAnim, mBool);
        yield return 0;
    }
}
