using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class ButtonManager : MonoBehaviour {
    public Button[] buttons;
    public Sprite[] images;
    public Image[] fishOneImages, fishTwoImages, fishThreeImages;

    public Sprite filledFish;
    public Image clearFish;
    // Start is called before the first frame update

    void Start() {
        SaveData data = SaveSystem.LoadPlayer();
        Debug.Log("Fish: " + data.fishInfo[0] + data.fishInfo[1]);
        Debug.Log("Level: " + data.levelInfo);

        int idx = 0;
        for(; idx <= data.levelInfo && idx < buttons.Length; idx++) {
            buttons[idx].interactable = true;
            buttons[idx].GetComponent<Image>().sprite = images[0];
    
            // int i = 0;
            // for(; i < data.fishInfo[idx]; i++) {
            //     mImages[i].sprite = fishSprite;
            // }
            // for(; i < 3; i++) {
            //     mImages[i] = fishImage;
            // }
        }

        for(; idx < buttons.Length; idx++) {
            buttons[idx].interactable = false;
            buttons[idx].GetComponent<Image>().sprite = images[1];
        }

        // TODO - REMOVE FOR FUTURE
        buttons[2].interactable = false;
        buttons[2].GetComponent<Image>().sprite = images[1];

        // List<Image[]> mImages = new List<Image[]>() {fishOneImages, fishTwoImages, fishThreeImages};
        // for(idx = 0; idx < buttons.Length; idx++) {
        //     int i = 0;
        //     for(; i < data.fishInfo[idx]; i++) {
        //         mImages[idx][i].sprite = filledFish;
        //     }
        //     for(; i < 3; i++) {
        //         mImages[idx][i] = clearFish;
        //     }
        // }

        // TESTING
        for(int i = 0; i < buttons.Length; i++)
            Debug.Log("Button"+i+": " + buttons[i].interactable);
    } // End of Start

    // TODO - Add safety feature to prevent player from accidentally resetting game
    public void ResetGame() {
        SaveSystem.SavePlayer(null);
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    } // End of ResetGame
}
