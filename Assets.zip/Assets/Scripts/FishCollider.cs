using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FishCollider : MonoBehaviour
{
    FishCountController fcc;
    PlayerController pc;
    private bool didFishMove, randomFlop;
    public AudioSource source;
    private Animator mAnimator;

    // Start is called before the first frame update
    void Start()
    {
        fcc = (GameObject.FindGameObjectWithTag("Canvas")).GetComponent<FishCountController>();
        pc = FindObjectOfType<PlayerController>();
        didFishMove = false;
        randomFlop = true;
        mAnimator = gameObject.GetComponent<Animator>();

        StartCoroutine(randomFlopAnimation()); // Start coroutine to have fish randomly flop
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("PlayerObj"))
        {

            int currentHeight = pc.level[pc.beary, pc.bearx];


            int forwardBlockHeight = pc.level[pc.beary - 1, pc.bearx];
            int rightBlockHeight = pc.level[pc.beary, pc.bearx + 1];
            int backBlockHeight = pc.level[pc.beary + 1, pc.bearx];
            int leftBlockHeight = pc.level[pc.beary, pc.bearx - 1];

            int[] possibleMoveLocations = new int[4];
            int numLocations = 0;


            if (currentHeight == forwardBlockHeight)
            {
                possibleMoveLocations[0] = forwardBlockHeight;
                numLocations++;
            }

            if (currentHeight == rightBlockHeight)
            {
                possibleMoveLocations[1] = rightBlockHeight;
                numLocations++;
            }

            if (currentHeight == backBlockHeight)
            {
                possibleMoveLocations[2] = backBlockHeight;
                numLocations++;
            }

            if (currentHeight == leftBlockHeight)
            {
                possibleMoveLocations[3] = leftBlockHeight;
                numLocations++;
            }

            //check for no possible move locations
            if (numLocations == 0)
            {
                eatFish();
                return;
            }

            //pick random location?
            int randomLocation = Random.Range(0, numLocations);
            
            if(didFishMove)
                eatFish();
            else {
                if(randomLocation == 3)
                    gameObject.transform.position += Vector3.left;
                else if(randomLocation == 2)
                    gameObject.transform.position += Vector3.back;
                else if(randomLocation == 1)
                    gameObject.transform.position += Vector3.right;
                else if(randomLocation == 0)
                    gameObject.transform.position += Vector3.forward;
                
                didFishMove = true;
                mAnimator.SetTrigger("flopping");
            }
        }
    }

    void eatFish()
    {
        source.Play();
        fcc.updateImages(fcc.getFishCount());
        fcc.updateFishCount(1);
        Destroy(this.gameObject);
    }

    IEnumerator randomFlopAnimation() {
        while(true) {
            yield return new WaitForSeconds(Random.Range(5f, 10f));
            mAnimator.SetTrigger("flopping");
            Debug.Log(this.gameObject.name + " is flopping");
            randomFlop = true;
        }
    } // End of randomFlopAnimation
}

