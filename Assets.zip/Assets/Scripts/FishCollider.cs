using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FishCollider : MonoBehaviour
{
    FishCountController fcc;
    PlayerController pc;
    private bool didFishMove;
    private AudioSource source;
    [SerializeField] private AudioClip mAudioEat, mAudioFlop;
    private Animator mAnimator;

    // Start is called before the first frame update
    void Start()
    {
        fcc = (GameObject.FindGameObjectWithTag("Canvas")).GetComponent<FishCountController>();
        pc = FindObjectOfType<PlayerController>();
        didFishMove = false;
        mAnimator = gameObject.GetComponent<Animator>();
        source = GetComponent<AudioSource>();

        StartCoroutine(randomFlop()); // Start coroutine to have fish randomly flop
    }

    void OnTriggerEnter(Collider other)
    {

        

        if (other.gameObject.CompareTag("PlayerObj")) {
            int currentHeight = pc.level[pc.beary, pc.bearx];


            int forwardBlockHeight = pc.level[pc.beary - 1, pc.bearx];
            int rightBlockHeight = pc.level[pc.beary, pc.bearx + 1];
            int backBlockHeight = pc.level[pc.beary + 1, pc.bearx];
            int leftBlockHeight = pc.level[pc.beary, pc.bearx - 1];

            var locations = new List<Vector3>();

            if(currentHeight == forwardBlockHeight)
                locations.Add(Vector3.forward);
            if(currentHeight == backBlockHeight)
                locations.Add(Vector3.back);
            if(currentHeight == rightBlockHeight)
                locations.Add(Vector3.right);
            if(currentHeight == leftBlockHeight)
                locations.Add(Vector3.left);

            //pick random location?
            int randomLocation = Random.Range(0, locations.Count+2);

            if(locations.Count == 0 || randomLocation >= locations.Count)
                didFishMove = true;

            if(didFishMove)
                StartCoroutine(eatFish(other.gameObject));
            else {
                gameObject.transform.position += locations[(int)Random.Range(0, locations.Count)];
                didFishMove = true;
                mAnimator.SetTrigger("flopping");
                source.PlayOneShot(mAudioFlop);
            }
        }
    }

    IEnumerator eatFish(GameObject player) {
        source.PlayOneShot(mAudioEat);
        fcc.updateImages(fcc.getFishCount());
        fcc.updateFishCount(1);
        player.GetComponentInChildren<PlayerController>().fishCount = fcc.getFishCount();
        Debug.Log("FishCollider Fish count: " + player.GetComponentInChildren<PlayerController>().fishCount);
        GetComponentInChildren<SkinnedMeshRenderer>().enabled = false;
        yield return new WaitForSeconds(mAudioEat.length);
        Destroy(this.gameObject);
    }

    IEnumerator randomFlop() {
        while(true) {
            yield return new WaitForSeconds(Random.Range(5f, 10f));
            mAnimator.SetTrigger("flopping");
            source.PlayOneShot(mAudioFlop);
            // Debug.Log(this.gameObject.name + " is flopping");
        }
    } // End of randomFlopAnimation
}

