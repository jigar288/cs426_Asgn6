using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PianoAudioController : MonoBehaviour {
    [SerializeField] private AudioClip mAudio;
    private AudioSource mAudioSource;
    // Start is called before the first frame update
    void Start() {
        mAudioSource = GetComponent<AudioSource>();
        StartCoroutine(playAudio());
    }

    IEnumerator playAudio() {
        while(true) {
            yield return new WaitForSeconds(Random.Range(10f, 20f));
            mAudioSource.PlayOneShot(mAudio);
            Debug.Log("Playing song");
            yield return new WaitForSeconds(mAudio.length);
            Debug.Log("Song just ended");
        }
    }
}
