using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class LevelSelect : MonoBehaviour
{
    public AudioSource myFx;

    public AudioClip hoverFx, clickFx;

    public GameObject startPanel, rotatePanel;

    public void HoverSound(){
        if(this.gameObject.GetComponent<Button>().interactable)
            myFx.PlayOneShot(hoverFx);
    } // End of HoverSound

    public void ClickSound(){
        if(this.gameObject.GetComponent<Button>().interactable)
            myFx.PlayOneShot(clickFx);
    } // End of ClickSound


    public void Select(string levelname){
        Debug.Log("Hi");
        SceneManager.LoadScene(levelname);
    } // End of Select

    public void test(){
        Debug.Log("Yo");
    }

    public void remove_start_screen(){
        startPanel.SetActive(false);
    }

    public void remove_rotate_screen(){
        rotatePanel.SetActive(false);
    }


}
