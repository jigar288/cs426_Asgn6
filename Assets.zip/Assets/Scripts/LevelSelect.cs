using UnityEngine;
using UnityEngine.SceneManagement; 

public class LevelSelect : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public AudioSource myFx;

    public AudioClip hoverFx, clickFx;

    public void HoverSound(){
        myFx.PlayOneShot(hoverFx);
    }

    public void ClickSound(){
        myFx.PlayOneShot(clickFx);
    }


    public void Select(string levelname){
        Debug.Log("Hi");
        SceneManager.LoadScene(levelname);
    }

    public void test(){
        Debug.Log("Yo");
    }
}
